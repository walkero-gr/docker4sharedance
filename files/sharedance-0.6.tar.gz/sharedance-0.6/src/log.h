#ifndef __LOG_H__
#define __LOG_H__ 1

void logfile(const int crit, const char *format, ...);

#endif
