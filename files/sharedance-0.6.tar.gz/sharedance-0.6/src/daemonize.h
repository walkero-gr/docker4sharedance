#ifndef __DAEMONIZE_H__
#define __DAEMONIZE_H__ 1

void dodaemonize(void);

#endif
