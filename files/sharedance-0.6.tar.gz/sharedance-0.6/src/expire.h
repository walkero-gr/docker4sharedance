#ifndef __EXPIRE_H__
#define __EXPIRE_H__ 1

int expire(void);

#endif
