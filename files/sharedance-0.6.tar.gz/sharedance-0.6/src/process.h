#ifndef __PROCESS_H__
#define __PROCESS_H__

void new_client(const int listen_fd, short event, void *ev);

#endif
